
function preload(){
  //imagens pré-carregadas
}

function setup(){
  createCanvas(400,400);
  //crie sprite aqui
}

function draw() {
  background(0);

}
